GRAVITAS+ LOGO PACK
===================

"Logo" is the monogram, the faceted G.
"Logotype" is the full wordmark, Gravitas+.

SVG/   Vector, for screen and for anything you will resize.
PDF/   Vector, for print and for handing to a printer or a partner.
AI/    Adobe Illustrator sources. Edit these only to produce a new
       colour variant; the geometry is final.
Web/   The files the website itself ships, including the favicon and
       the spacetime-well texture.

COLOURS
  White   #f1efec   on Cosmos Blue, Royal Black or space imagery. Most common.
  Blue    #003049   on White Tint, Sisal or any light background.
  Black   #030303   single-colour reproduction and very light print.
  Sisal   #d4c9be   rare, for tonal work and watermarks on dark.

ON THE WEB
  Inline the SVG and set fill="currentColor" instead of picking a variant,
  so the mark follows the page theme.

RULES
  Keep the plus. Do not rebuild the wordmark in a font. Do not stretch,
  rotate, recolour outside the palette, or add effects to the mark itself.
  Clear space: the cap height of the G around the logotype, 25% of the icon
  width around the monogram. Minimum size: logotype 120px wide, monogram
  24px. Below that, use the monogram.

Full guidance: /brand
